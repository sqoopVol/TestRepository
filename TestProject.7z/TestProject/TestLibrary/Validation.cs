﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TestLibrary
{
    public class Validation
    {
        public static bool FieldsValidation(string field1, string field2, string field3, string field4)
        {
            Regex reg1 = new Regex(@"^[a-zA-Z\s]{10,60}$");
            Regex reg2 = new Regex(@"^[^@\s]+@[^@\s]+\.[^@\s]+$");
            Regex reg3 = new Regex(@"^\+\d\s\(\d{3}\)\s\d{3}-\d{2}-\d{2}$");
            Regex reg4 = new Regex(@"^[a-zA-Z\s\w]{20,85}$");

            if (reg1.IsMatch(field1) && reg2.IsMatch(field2) && reg3.IsMatch(field3) && reg4.IsMatch(field4))
                return true;
            else return false;
        }
    }
}
