﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestUnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            string testValue1 = "Vtiurin Danil Vladimirovich";
            string testValue2 = "danil20031209@gmail.com";
            string testValue3 = "+7 (913) 702-53-35";
            string testValue4 = "Novosibirsk abababababababababababababababa";

            bool expected = true;

            bool actual = TestLibrary.Validation.FieldsValidation(testValue1, testValue2, testValue3, testValue4);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethod2()
        {
            string testValue1 = "Danil";
            string testValue2 = "danil20031209!gmail,com";
            string testValue3 = "+7(913)7025335";
            string testValue4 = "Novosibirsk";

            bool expected = false;

            bool actual = TestLibrary.Validation.FieldsValidation(testValue1, testValue2, testValue3, testValue4);

            Assert.AreEqual(expected, actual);
        }
    }
}
